from __future__ import annotations

import sympy as sp

from gu_toolkit import Figure, parameters


def test_param_change_hooks_run_inside_triggering_figure_context() -> None:
    x, a, c = sp.symbols("x a c")
    fig1 = Figure(default_x_range=(-6, 6), default_y_range=(-3, 3))
    fig2 = Figure(default_x_range=(-4, 4), default_y_range=(-2, 2))

    with fig1:
        fig1.parameter(a)
        fig1.plot(a * sp.sin(x), x, id="a_sin")
        parameters[a].value = 1

    with fig2:
        fig2.parameter(c)
        fig2.plot(c * sp.cos(x), x, id="c_cos")
        parameters[c].value = 1

    log: list[tuple[str, float]] = []

    def hook_fig1(event):
        log.append(("fig1", float(parameters[a].value), float(event.new)))

    def hook_fig2(event):
        log.append(("fig2", float(parameters[c].value), float(event.new)))

    fig1.add_param_change_hook(hook_fig1, run_now=False)
    fig2.add_param_change_hook(hook_fig2, run_now=False)

    fig1.parameter(a).value = 2
    fig2.parameter(c).value = 3
    fig1.flush_render_queue()
    fig2.flush_render_queue()

    assert log[0] == ("fig1", 2.0, 2.0)
    assert log[1] == ("fig2", 3.0, 3.0)
