import numpy as np
import sympy as sp
from gu_toolkit.NamedFunction import NamedFunction
from gu_toolkit.numpify import numpify, numpify_cached

__all__ = ["create_mystery_function"]


def create_mystery_function(N, debug=False):
    r"""
    Create a mystery function of the form
    $$
    F(x)= α_1\,\sin(2 π x)+α_2\,\sin(2 π 2 x) + \ldots +α_{N} \,\sin(2 π N x)
    $$

    The numbers $α_n$ are chosen randomly **between -1 and 1** with **step 0.1**.
    """
    x = sp.Symbol("x")

    @NamedFunction
    def F(arg):
        return None

    # Generate the mystery coefficients and build the symbolic expression.
    expr = 0
    for n in [n + 1 for n in range(N)]:  # n goes from 1 to modes inclusive
        # Generate random integer j from 0 to 20
        j = np.random.randint(3, 10 + 1)
        sign = np.random.randint(0, 1 + 1)
        a_n = sp.Integer(-1) ** (sp.Integer(sign)) * sp.Rational(j, 10)
        # Add term to the expression
        expr = expr + a_n * sp.sin(2 * sp.pi * n * x)
    if debug:
        print(expr)
    f_numpy = numpify(expr)
    F.f_numpy = f_numpy
    return F


__all__ += ["SupNormCard", "MaxDistanceCard"]


def _metric_card(description, var, expr, reducer):
    """Return a Figure.info-compatible mixed static/dynamic card spec."""
    interval = (-0.5, 0.5)
    xs = np.linspace(interval[0], interval[1], 2000)
    expr = sp.Abs(sp.sympify(expr))
    params = tuple(
        sorted((s for s in expr.free_symbols if s != var), key=lambda s: s.sort_key())
    )
    expr_np = numpify_cached(expr, vars=(var, *params))

    def _value(fig, _ctx):
        missing = [p for p in params if p not in fig.parameters]
        if missing:
            fig.parameter(missing)
        par_vals = [fig.parameters[p].value for p in params]
        values = np.asarray(expr_np(xs, *par_vals), dtype=float)
        metric_value = float(reducer(values))
        return f"<code>{metric_value:g}</code>"

    return [description, _value]


def MaxDistanceCard(var, F, G):
    return SupNormCard(var, F - G)


def SupNormCard(var, F):
    return _metric_card(
        (
            r"The largest distance between the two functions on "
            r"$\left[-\tfrac12,\tfrac12\right]$ is:"
        ),
        var,
        F,
        np.max,
    )
